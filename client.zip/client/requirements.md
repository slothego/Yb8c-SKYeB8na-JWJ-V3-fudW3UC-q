## Packages
framer-motion | Smooth animations for dialogs and transitions
lucide-react | Beautiful icons for the UI
date-fns | Formatting dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'JetBrains Mono'", "'Fira Code'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
}
